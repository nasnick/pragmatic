title = "ghostbusters"

a = title.reverse
puts a

b = a.reverse
puts b

puts title.reverse.reverse

puts title.capitalize.ljust(30, '.')
formatted_title = title.capitalize.ljust(30, '.')
puts formatted_title

rank = 9

puts "#{formatted_title} #{rank}"
